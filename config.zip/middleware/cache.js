const { redisGet, redisExists } = require('../model/redis')

module.exports = async (req, res, next) => {
  
}