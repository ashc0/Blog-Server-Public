module.exports = {
  "dbUri": "mongodb+srv://hqy:lovelu1314@cluster0.64ah5.mongodb.net/blog?retryWrites=true&w=majority",
  "md5secret": "jufe",
  "jwtSecret": "ersola"
}